import { useState } from "react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Plus, Minus } from "lucide-react";

interface MetricInputProps {
  title: string;
  value: number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  step?: number;
  onUpdate: (value: number) => void;
}

export function MetricInput({ title, value, unit, icon, color, step = 1, onUpdate }: MetricInputProps) {
  const [inputValue, setInputValue] = useState(value.toString());

  const handleIncrement = () => {
    const newValue = value + step;
    onUpdate(newValue);
    setInputValue(newValue.toString());
  };

  const handleDecrement = () => {
    const newValue = Math.max(0, value - step);
    onUpdate(newValue);
    setInputValue(newValue.toString());
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);
    const numValue = parseFloat(newValue);
    if (!isNaN(numValue) && numValue >= 0) {
      onUpdate(numValue);
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-center gap-3 mb-4">
        <div className={`p-2 rounded-full ${color}`}>
          {icon}
        </div>
        <h3 className="font-medium">{title}</h3>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor={`${title}-input`}>Current Value</Label>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDecrement}
              className="h-8 w-8 p-0"
            >
              <Minus className="h-4 w-4" />
            </Button>
            <Input
              id={`${title}-input`}
              value={inputValue}
              onChange={handleInputChange}
              className="text-center"
              type="number"
              min="0"
              step={step}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={handleIncrement}
              className="h-8 w-8 p-0"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground text-center">{unit}</p>
        </div>

        <div className="text-center">
          <span className="text-2xl font-medium">{value.toLocaleString()}</span>
          <span className="text-sm text-muted-foreground ml-1">{unit}</span>
        </div>
      </div>
    </Card>
  );
}