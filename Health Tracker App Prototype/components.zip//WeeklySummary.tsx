import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { CircularProgress } from "./CircularProgress";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface WeeklyData {
  steps: { current: number; target: number; previous: number };
  sleep: { current: number; target: number; previous: number };
  water: { current: number; target: number; previous: number };
  weight: { current: number; target: number; previous: number };
}

interface WeeklySummaryProps {
  weekData: WeeklyData;
}

export function WeeklySummary({ weekData }: WeeklySummaryProps) {
  const getTrend = (current: number, previous: number) => {
    if (current > previous) return { icon: TrendingUp, color: "text-green-500", label: "up" };
    if (current < previous) return { icon: TrendingDown, color: "text-red-500", label: "down" };
    return { icon: Minus, color: "text-gray-500", label: "same" };
  };

  const getPercentageChange = (current: number, previous: number) => {
    if (previous === 0) return 0;
    return Math.round(((current - previous) / previous) * 100);
  };

  const metrics = [
    {
      name: "Steps",
      current: weekData.steps.current,
      target: weekData.steps.target,
      previous: weekData.steps.previous,
      unit: "steps",
      color: "#3b82f6",
      bgColor: "bg-blue-100"
    },
    {
      name: "Sleep", 
      current: weekData.sleep.current,
      target: weekData.sleep.target,
      previous: weekData.sleep.previous,
      unit: "hrs",
      color: "#8b5cf6",
      bgColor: "bg-purple-100"
    },
    {
      name: "Water",
      current: weekData.water.current,
      target: weekData.water.target,
      previous: weekData.water.previous,
      unit: "glasses",
      color: "#06b6d4",
      bgColor: "bg-cyan-100"
    },
    {
      name: "Weight",
      current: weekData.weight.current,
      target: weekData.weight.target,
      previous: weekData.weight.previous,
      unit: "lbs",
      color: "#f59e0b",
      bgColor: "bg-amber-100"
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="font-medium mb-6">Weekly Overview</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {metrics.map((metric) => {
            const trend = getTrend(metric.current, metric.previous);
            const percentageChange = getPercentageChange(metric.current, metric.previous);
            const TrendIcon = trend.icon;

            return (
              <div key={metric.name} className="text-center space-y-3">
                <CircularProgress
                  value={metric.current}
                  max={metric.target}
                  size={80}
                  strokeWidth={8}
                  color={metric.color}
                >
                  <div className="text-center">
                    <div className="font-medium">{metric.current}</div>
                    <div className="text-xs text-muted-foreground">{metric.unit}</div>
                  </div>
                </CircularProgress>
                
                <div>
                  <h4 className="font-medium text-sm">{metric.name}</h4>
                  <div className="flex items-center justify-center gap-1 mt-1">
                    <TrendIcon className={`h-3 w-3 ${trend.color}`} />
                    <span className={`text-xs ${trend.color}`}>
                      {percentageChange !== 0 && `${Math.abs(percentageChange)}%`}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-4">
          <h3 className="font-medium mb-3">Goals Achieved</h3>
          <div className="space-y-2">
            {metrics.map((metric) => {
              const achieved = metric.current >= metric.target;
              const percentage = Math.min((metric.current / metric.target) * 100, 100);
              
              return (
                <div key={metric.name} className="flex items-center justify-between">
                  <span className="text-sm">{metric.name}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant={achieved ? "default" : "secondary"}>
                      {Math.round(percentage)}%
                    </Badge>
                    {achieved && <div className="w-2 h-2 bg-green-500 rounded-full" />}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-medium mb-3">Weekly Insights</h3>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
              <p>You walked {weekData.steps.current.toLocaleString()} steps this week!</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0" />
              <p>Average sleep: {(weekData.sleep.current / 7).toFixed(1)} hours per night</p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-cyan-500 rounded-full mt-2 flex-shrink-0" />
              <p>Stay hydrated! You're averaging {(weekData.water.current / 7).toFixed(1)} glasses daily</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}