import { Card } from "./ui/card";
import { Progress } from "./ui/progress";

interface MetricCardProps {
  title: string;
  value: number;
  unit: string;
  target: number;
  icon: React.ReactNode;
  color: string;
}

export function MetricCard({ title, value, unit, target, icon, color }: MetricCardProps) {
  const percentage = Math.min((value / target) * 100, 100);
  
  return (
    <Card className="p-4 relative overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`p-2 rounded-full ${color}`}>
            {icon}
          </div>
          <h3 className="font-medium">{title}</h3>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-medium">{value.toLocaleString()}</span>
          <span className="text-sm text-muted-foreground">{unit}</span>
        </div>
        
        <Progress value={percentage} className="h-2" />
        
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Target: {target.toLocaleString()} {unit}</span>
          <span>{Math.round(percentage)}%</span>
        </div>
      </div>
    </Card>
  );
}